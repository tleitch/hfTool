require(testthat)
require(quantstrat)

test_check("quantstrat")
